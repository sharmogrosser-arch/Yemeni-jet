# Yemeni Jet — Android WebView APK Project

هذا المشروع يحوّل نسخة Yemeni Jet Web الحالية إلى تطبيق Android يستخدم WebView لعرض
نفس واجهة HTML/CSS/JavaScript داخل التطبيق.

## التطبيق
- الاسم: Yemeni Jet
- Package: com.yemenijet.app
- Orientation: Portrait
- RTL / Arabic
- JavaScript + Local Storage
- Back button يرجع داخل صفحات WebView
- الواجهة محفوظة داخل app/src/main/assets/index.html

## بناء APK
افتح المشروع في Android Studio ثم Run أو Build APK.
يمكن أيضًا استخدام أي Android cloud build service يدعم Gradle/Android projects.

## ملاحظة
البيانات الحالية تجريبية داخل HTML/JavaScript. للنسخة الإنتاجية يجب ربط قاعدة بيانات
وحسابات المستخدمين ولوحة تحكم ومولد QR/نظام تحقق للخصومات.
